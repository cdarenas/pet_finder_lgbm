import pandas as pd
import os
from sklearn.model_selection import StratifiedKFold, train_test_split
import optuna
import lightgbm as lgb
from sklearn.metrics import cohen_kappa_score
from lightgbm import early_stopping

# Crear carpeta
os.makedirs("folds", exist_ok=True)

# Cargar datos
df = pd.read_csv("train.csv")

# Feature engineering
df['CareLevel'] = df[['Vaccinated', 'Dewormed', 'Sterilized']].apply(
    lambda row: sum(1 for val in row if val == 1), axis=1)
df['ColorCount'] = df[['Color1', 'Color2', 'Color3']].gt(0).sum(axis=1)
df['IsMixedBreed'] = (df['Breed2'] > 0).astype(int)
df['HasPhotoVideo'] = ((df['PhotoAmt'] > 0) | (df['VideoAmt'] > 0)).astype(int)
df['TotalMedia'] = df['PhotoAmt'] + df['VideoAmt']
df['FeeBin'] = pd.cut(df['Fee'], bins=[-1, 0, 50, 200, df['Fee'].max()], labels=[0, 1, 2, 3]).astype(int)

features = [
    'Type', 'Age', 'Breed1', 'Breed2', 'Gender',
    'MaturitySize', 'FurLength', 'Health', 'Quantity', 'State',
    'CareLevel', 'ColorCount', 'IsMixedBreed', 'HasPhotoVideo', 'TotalMedia', 'FeeBin'
]
label = 'AdoptionSpeed'
X = df[features]
y = df[label]

# ------------------------
# Optimización con Optuna (Cross-Validation en 3 folds)
# ------------------------

X_train_opt, X_valid_opt, y_train_opt, y_valid_opt = train_test_split(X, y, stratify=y, test_size=0.2, random_state=42)


def objective(trial):
    params = {
        'objective': 'multiclass',
        'num_class': 5,
        'metric': 'multi_logloss',
        'verbosity': -1,
        'boosting_type': 'gbdt',
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.2),
        'num_leaves': trial.suggest_int('num_leaves', 15, 100),
        'min_data_in_leaf': trial.suggest_int('min_data_in_leaf', 10, 50),
        'feature_fraction': trial.suggest_float('feature_fraction', 0.5, 1.0),
        'bagging_fraction': trial.suggest_float('bagging_fraction', 0.5, 1.0),
        'bagging_freq': trial.suggest_int('bagging_freq', 1, 10),
        'lambda_l1': trial.suggest_float('lambda_l1', 1e-8, 10.0, log=True),
        'lambda_l2': trial.suggest_float('lambda_l2', 1e-8, 10.0, log=True),
        'feature_pre_filter': False
    }

    kf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    kappas = []

    for train_idx, valid_idx in kf.split(X_train_opt, y_train_opt):
        lgb_train = lgb.Dataset(X_train_opt.iloc[train_idx], label=y_train_opt.iloc[train_idx])
        lgb_valid = lgb.Dataset(X_train_opt.iloc[valid_idx], label=y_train_opt.iloc[valid_idx])

        model = lgb.train(
            params,
            lgb_train,
            valid_sets=[lgb_valid],
            num_boost_round=1000,
            callbacks=[early_stopping(50)]
        )

        y_pred = model.predict(X_train_opt.iloc[valid_idx])
        y_pred_labels = y_pred.argmax(axis=1)
        kappa = cohen_kappa_score(y_train_opt.iloc[valid_idx], y_pred_labels)
        kappas.append(kappa)

    return sum(kappas) / len(kappas)


study = optuna.create_study(direction="maximize")
study.optimize(objective, n_trials=50)

best_params = study.best_params
print("Mejores hiperparámetros:")
print(best_params)


# ------------------------
# Generar archivos para C++
# ------------------------

def export_lgbm_file(X_df, y_df, filename):
    df_out = pd.concat([y_df.reset_index(drop=True), X_df.reset_index(drop=True)], axis=1)
    df_out.to_csv(filename, sep='\t', index=False, header=False)


kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

for fold_idx, (train_idx, valid_idx) in enumerate(kfold.split(X, y)):
    X_train, X_valid = X.iloc[train_idx], X.iloc[valid_idx]
    y_train, y_valid = y.iloc[train_idx], y.iloc[valid_idx]

    train_file = f"folds/train_fold_{fold_idx}.txt"
    valid_file = f"folds/valid_fold_{fold_idx}.txt"
    valid_labels = f"folds/y_valid_fold_{fold_idx}.txt"
    model_file_txt = f"folds/model_fold_{fold_idx}.txt"
    pred_file = f"folds/predictions_fold_{fold_idx}.txt"
    config_train_file = f"folds/config_train_fold_{fold_idx}.txt"
    config_pred_file = f"folds/config_pred_fold_{fold_idx}.txt"

    export_lgbm_file(X_train, y_train, train_file)
    export_lgbm_file(X_valid, y_valid, valid_file)
    y_valid.reset_index(drop=True).to_csv(valid_labels, index=False, header=False)

    config_train_text = f"""task=train
objective=multiclass
num_class=5
metric=multi_logloss,multi_error
data={train_file}
valid_data={valid_file}
label_column=0
output_model={model_file_txt}
num_iterations=1000
early_stopping_round=50
learning_rate={best_params['learning_rate']}
num_leaves={best_params['num_leaves']}
min_data_in_leaf={best_params['min_data_in_leaf']}
feature_fraction={best_params['feature_fraction']}
bagging_fraction={best_params['bagging_fraction']}
bagging_freq={best_params['bagging_freq']}
lambda_l1={best_params['lambda_l1']}
lambda_l2={best_params['lambda_l2']}
verbosity=1
"""
    with open(config_train_file, "w") as f:
        f.write(config_train_text)

    config_pred_text = f"""task=predict
input_model={model_file_txt}
data={valid_file}
output_result={pred_file}
"""
    with open(config_pred_file, "w") as f:
        f.write(config_pred_text)

# ---------- Archivo con todo el dataset ----------
all_train_file = "folds/train_all.txt"
export_lgbm_file(X, y, all_train_file)

all_config_file = "folds/config_train_all.txt"
config_all_text = f"""task=train
objective=multiclass
num_class=5
metric=multi_logloss,multi_error
data={all_train_file}
label_column=0
output_model=folds/model_all.txt
num_iterations=1000
learning_rate={best_params['learning_rate']}
num_leaves={best_params['num_leaves']}
min_data_in_leaf={best_params['min_data_in_leaf']}
feature_fraction={best_params['feature_fraction']}
bagging_fraction={best_params['bagging_fraction']}
bagging_freq={best_params['bagging_freq']}
lambda_l1={best_params['lambda_l1']}
lambda_l2={best_params['lambda_l2']}
verbosity=1
save_binary=true
"""
with open(all_config_file, "w") as f:
    f.write(config_all_text)

print("✅ Archivos de folds + train_all.txt + config_train_all.txt generados exitosamente.")

import os
import json
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd
import optuna
import lightgbm as lgb
from lightgbm import early_stopping, record_evaluation, log_evaluation
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import cohen_kappa_score
from sklearn.preprocessing import LabelEncoder

# =============================================================================
# Configuración general
# =============================================================================
os.makedirs("folds", exist_ok=True)

# Bandera para activar/desactivar las features de hojas del Random Forest
# (dejar este nombre para poder alternar fácilmente la característica)
USER_RF_LEAF_FEATURES = True

# Optuna storage (para dashboard)
STUDY_NAME = "petfinder-lgbm-kappa"
storage_db = Path("folds/optuna_study.db").resolve().as_posix()
STORAGE_URL = f"sqlite:///{storage_db}"

# =============================================================================
# Cargar datos
# =============================================================================
df = pd.read_csv("train.csv")


# =============================================================================
# Feature engineering (nombres CamelCase)
# =============================================================================
def classify_care(row: pd.Series) -> str:
    """Clasifica el nivel de cuidado a partir de Vaccinated, Dewormed y Sterilized."""
    values = [row["Vaccinated"], row["Dewormed"], row["Sterilized"]]
    cnt = values.count(1)
    if cnt == 3:
        return "excelente"
    elif cnt == 2:
        return "bueno"
    elif cnt == 1:
        return "regular"
    else:
        return "otro"


df["Care"] = df.apply(classify_care, axis=1)


def classify_color(row: pd.Series) -> str:
    """Clasifica el patrón de color usando Color1/2/3."""
    if row["Color2"] == 0 and row["Color3"] == 0:
        return "one_color"
    elif row["Color3"] == 0:
        return "two_colors"
    else:
        return "multicolors"


df["ColorPattern"] = df.apply(classify_color, axis=1)

# Extras
df["HasName"] = (df["Name"].fillna("").str.strip() != "").astype(int)
df["DescLength"] = df["Description"].fillna("").apply(lambda x: len(x.split()))
df["PhotoDescCombo"] = df["PhotoAmt"] * df["DescLength"]
df["FeeZero"] = (df["Fee"] == 0).astype(int)
df["IsBaby"] = (df["Age"] < 6).astype(int)

# Conteo por RescuerID (valor global inicial; en CV se recalcula por fold)
rescuer_counts = (
    df.groupby("RescuerID")["PetID"].nunique().rename("RescuerListingCount")
)
df = df.join(rescuer_counts, on="RescuerID")
df["RescuerListingCount"] = df["RescuerListingCount"].fillna(1)

# Encode de categóricas y persistencia de mapeos (para replicar en test)
ENC_PATH = Path("folds/encoders.json")
encoders_map = {}
for col in ["Care", "ColorPattern"]:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col].astype(str))
    encoders_map[col] = {cls: int(i) for i, cls in enumerate(le.classes_)}
ENC_PATH.parent.mkdir(parents=True, exist_ok=True)
ENC_PATH.write_text(json.dumps(encoders_map, indent=2), encoding="utf-8")


# =============================================================================
# Helpers: RF-leaf features por fold (sin fuga)
# =============================================================================
def build_rf_leaf_features_train_valid(
        X_tr_base: pd.DataFrame,
        X_va_base: pd.DataFrame,
        y_tr: pd.Series,
        *,
        num_trees: int = 20,
        num_leaves: int = 16,
        min_data_in_leaf: int = 100,
        mtry_ratio: float = 0.2,
        seed: int = 42,
):
    """
    Entrena un LightGBM 'rf' SOLO con el train del fold y genera:
      - Para train y valid: one-hots por hoja/árbol (alineados).
    Devuelve X_tr_ext, X_va_ext y la lista de columnas RF agregadas.
    """
    dtrain = lgb.Dataset(X_tr_base, label=y_tr, free_raw_data=False)
    rf_params = {
        "boosting_type": "rf",
        "objective": "multiclass",
        "num_class": int(y_tr.nunique()),
        "bagging_freq": 1,
        "bagging_fraction": 1 - 1 / np.exp(1),  # ~0.632
        "feature_fraction": 1.0,
        "feature_fraction_bynode": mtry_ratio,
        "max_bin": 31,
        "num_leaves": num_leaves,
        "min_data_in_leaf": min_data_in_leaf,
        "verbosity": -1,
        "force_row_wise": True,
        "extra_trees": False,
        "seed": seed,
        "num_iterations": num_trees,
    }
    rf_model = lgb.train(rf_params, dtrain)

    leaf_tr = rf_model.predict(X_tr_base, pred_leaf=True)
    leaf_va = rf_model.predict(X_va_base, pred_leaf=True)

    def one_hot_by_tree(leaf_mat: np.ndarray, index: pd.Index) -> pd.DataFrame:
        """One-hot por hoja para cada árbol, concatenado a lo ancho."""
        dummies_list = []
        for t in range(leaf_mat.shape[1]):
            s = pd.Series(leaf_mat[:, t], index=index, name=f"Leaf_{t:03}", dtype="int32")
            d = pd.get_dummies(s, prefix=f"RF_{t:03}", dtype="uint8")
            dummies_list.append(d)
        return pd.concat(dummies_list, axis=1)

    rf_tr = one_hot_by_tree(leaf_tr, X_tr_base.index)
    rf_va = one_hot_by_tree(leaf_va, X_va_base.index)
    rf_va = rf_va.reindex(columns=rf_tr.columns, fill_value=0)  # alinear columnas

    X_tr_ext = pd.concat([X_tr_base, rf_tr], axis=1)
    X_va_ext = pd.concat([X_va_base, rf_va], axis=1)
    return X_tr_ext, X_va_ext, list(rf_tr.columns)


# =============================================================================
# Helpers: persistir/aplicar encoder de hojas RF (para train_all & test)
# =============================================================================
def _one_hot_by_tree(leaf_mat: np.ndarray, index: pd.Index) -> pd.DataFrame:
    """One-hot por hoja para cada árbol (uso interno)."""
    dummies = []
    for t in range(leaf_mat.shape[1]):
        s = pd.Series(leaf_mat[:, t], index=index, name=f"Leaf_{t:03}", dtype="int32")
        d = pd.get_dummies(s, prefix=f"RF_{t:03}", dtype="uint8")
        dummies.append(d)
    return pd.concat(dummies, axis=1)


def fit_save_rf_leaf_encoder(
        X_fit: pd.DataFrame,
        y_fit: pd.Series,
        *,
        num_trees=20,
        num_leaves=16,
        min_data_in_leaf=100,
        mtry_ratio=0.2,
        seed=42,
):
    """
    Entrena el 'rf' sobre TODO el train, guarda:
      - Modelo (txt) y lista de columnas RF (json).
    Devuelve el one-hot del train y las columnas RF.
    """
    dtrain = lgb.Dataset(X_fit, label=y_fit, free_raw_data=False)
    rf_params = {
        "boosting_type": "rf",
        "objective": "multiclass",
        "num_class": int(y_fit.nunique()),
        "bagging_freq": 1,
        "bagging_fraction": 1 - 1 / np.exp(1),
        "feature_fraction": 1.0,
        "feature_fraction_bynode": mtry_ratio,
        "max_bin": 31,
        "num_leaves": num_leaves,
        "min_data_in_leaf": min_data_in_leaf,
        "verbosity": -1,
        "force_row_wise": True,
        "extra_trees": False,
        "seed": seed,
        "num_iterations": num_trees,
    }
    rf_model = lgb.train(rf_params, dtrain)

    leaf_train = rf_model.predict(X_fit, pred_leaf=True)
    rf_train = _one_hot_by_tree(leaf_train, X_fit.index)
    rf_cols = list(rf_train.columns)

    Path("folds/rf_leaf_encoder.txt").write_text(
        rf_model.model_to_string(), encoding="utf-8"
    )
    Path("folds/rf_leaf_columns.json").write_text(
        json.dumps(rf_cols, indent=2), encoding="utf-8"
    )
    return rf_train, rf_cols


def transform_with_saved_rf_encoder(X_in: pd.DataFrame) -> pd.DataFrame:
    """Aplica el modelo RF guardado y alinea columnas con el vocabulario persistido."""
    rf_model = lgb.Booster(
        model_str=Path("folds/rf_leaf_encoder.txt").read_text(encoding="utf-8")
    )
    rf_cols = json.loads(
        Path("folds/rf_leaf_columns.json").read_text(encoding="utf-8")
    )
    leaf = rf_model.predict(X_in, pred_leaf=True)
    rf_df = _one_hot_by_tree(leaf, X_in.index)
    rf_df = rf_df.reindex(columns=rf_cols, fill_value=0)
    return rf_df


# =============================================================================
# Conjuntos de features / label (sin RF-leaves globales)
# =============================================================================
label = "AdoptionSpeed"
base_features_for_rf = [
    "Type",
    "Age",
    "Breed1",
    "Breed2",
    "Gender",
    "MaturitySize",
    "FurLength",
    "Health",
    "Quantity",
    "State",
    "Care",
    "ColorPattern",
    "HasName",
    "DescLength",
    "PhotoDescCombo",
    "FeeZero",
    "IsBaby",
    "RescuerListingCount",
]

# Importante: aún no generamos RF-leaves globales (solo en train_all/test si la bandera está activa)
features = base_features_for_rf
X = df[features]
y = df[label]
NUM_CLASS = int(y.nunique())

# Categóricas para LightGBM
CATEGORICALS = ["Care", "ColorPattern"]

# Split para que Optuna trabaje sobre un 80% y reporte en 5-folds internos
X_train_opt, X_valid_opt, y_train_opt, y_valid_opt = train_test_split(
    X, y, stratify=y, test_size=0.2, random_state=42
)


# =============================================================================
# Métrica custom: Quadratic Weighted Kappa (QWK)
# =============================================================================
def lgb_kappa_metric(preds: np.ndarray, dataset: lgb.Dataset):
    """Métrica QWK como 'feval' de LightGBM (usa argmax sobre probabilidades)."""
    y_true = dataset.get_label().astype(int)
    preds_2d = preds.reshape(NUM_CLASS, -1).T
    y_pred = np.argmax(preds_2d, axis=1)
    score = cohen_kappa_score(y_true, y_pred, weights="quadratic")
    return ("KAPPA", float(score), True)


def inject_rescuer_count_fold(
        X_tr_base: pd.DataFrame,
        X_va_base: pd.DataFrame,
        tr_idx: np.ndarray,
        va_idx: np.ndarray,
        df_full: pd.DataFrame,
):
    """
    Recalcula RescuerListingCount SOLO con filas del train del fold
    y lo inyecta en train/valid (evita fuga de información).
    """
    counts = df_full.iloc[tr_idx].groupby("RescuerID")["PetID"].nunique()
    X_tr_base = X_tr_base.copy()
    X_va_base = X_va_base.copy()
    X_tr_base["RescuerListingCount"] = (
        df_full["RescuerID"].iloc[tr_idx].map(counts).fillna(1).values
    )
    X_va_base["RescuerListingCount"] = (
        df_full["RescuerID"].iloc[va_idx].map(counts).fillna(1).values
    )
    return X_tr_base, X_va_base


# =============================================================================
# Optimización con Optuna (5-fold CV) — sin fuga en RF-leaves
# =============================================================================
def objective(trial: optuna.Trial) -> float:
    """Objetivo de Optuna: maximizar QWK en 5-fold CV."""
    params = {
        "objective": "multiclass",
        "num_class": NUM_CLASS,
        "metric": "None",
        "verbosity": -1,
        "boosting_type": "gbdt",
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2),
        "num_leaves": trial.suggest_int("num_leaves", 15, 100),
        "min_data_in_leaf": trial.suggest_int("min_data_in_leaf", 10, 50),
        "feature_fraction": trial.suggest_float("feature_fraction", 0.5, 1.0),
        "bagging_fraction": trial.suggest_float("bagging_fraction", 0.5, 1.0),
        "bagging_freq": trial.suggest_int("bagging_freq", 1, 10),
        "lambda_l1": trial.suggest_float("lambda_l1", 1e-8, 10.0, log=True),
        "lambda_l2": trial.suggest_float("lambda_l2", 1e-8, 10.0, log=True),
        "feature_pre_filter": False,
        "seed": 42,
        "feature_fraction_seed": 42,
        "bagging_seed": 42,
        "drop_seed": 42,
    }

    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    kappas = []
    global_step = 0

    for fold_idx, (tr_idx, va_idx) in enumerate(kf.split(X_train_opt, y_train_opt)):
        X_tr_base = X_train_opt.iloc[tr_idx].copy()
        y_tr = y_train_opt.iloc[tr_idx]
        X_va_base = X_train_opt.iloc[va_idx].copy()
        y_va = y_train_opt.iloc[va_idx]

        # Mapear a posiciones reales del df original (para calcular el conteo sin fuga)
        tr_pos = df.index.get_indexer(X_train_opt.index[tr_idx])
        va_pos = df.index.get_indexer(X_train_opt.index[va_idx])

        # Recalcular RescuerListingCount SOLO con TRAIN del fold
        X_tr_base, X_va_base = inject_rescuer_count_fold(
            X_tr_base, X_va_base, tr_idx=tr_pos, va_idx=va_pos, df_full=df
        )

        # Extender con RF-leaves por fold (sin fuga)
        if USER_RF_LEAF_FEATURES:
            X_tr, X_va, _ = build_rf_leaf_features_train_valid(
                X_tr_base,
                X_va_base,
                y_tr,
                num_trees=20,
                num_leaves=16,
                min_data_in_leaf=100,
                mtry_ratio=0.2,
                seed=42,
            )
        else:
            X_tr, X_va = X_tr_base, X_va_base

        dtr = lgb.Dataset(
            X_tr,
            label=y_tr,
            categorical_feature=[c for c in CATEGORICALS if c in X_tr.columns],
            free_raw_data=False,
        )
        dva = lgb.Dataset(
            X_va,
            label=y_va,
            categorical_feature=[c for c in CATEGORICALS if c in X_va.columns],
            free_raw_data=False,
        )

        eval_hist = {}
        model = lgb.train(
            params,
            dtr,
            valid_sets=[dva],
            valid_names=[f"valid_fold{fold_idx}"],
            num_boost_round=1000,
            feval=lgb_kappa_metric,
            callbacks=[
                early_stopping(50, verbose=False),
                record_evaluation(eval_hist),
                log_evaluation(0),
            ],
        )

        valid_key = next(k for k in eval_hist.keys() if k.startswith("valid"))
        hist = eval_hist[valid_key]["KAPPA"]
        for score in hist:
            global_step += 1
            trial.report(float(score), step=global_step)

        y_pred = model.predict(X_va, num_iteration=model.best_iteration)
        y_pred_labels = y_pred.argmax(axis=1)
        kappa = cohen_kappa_score(y_va, y_pred_labels, weights="quadratic")
        print(f"[CV] Fold {fold_idx}: KAPPA={kappa:.4f}, best_iter={model.best_iteration}")
        kappas.append(kappa)

    mean_kappa = float(np.mean(kappas))
    print(f"[CV] Mean KAPPA (trial): {mean_kappa:.4f}")
    return mean_kappa


# =============================================================================
# Ejecutar Optuna Study
# =============================================================================
study = optuna.create_study(
    direction="maximize", storage=STORAGE_URL, study_name=STUDY_NAME, load_if_exists=True
)
study.optimize(objective, n_trials=50)

best_params = study.best_params
best_params.update({"seed": 42, "feature_fraction_seed": 42, "bagging_seed": 42, "drop_seed": 42})
print("Mejores hiperparámetros (KAPPA):")
print(best_params)

with open("folds/best_params_kappa.json", "w") as f:
    json.dump(best_params, f, indent=2)


# =============================================================================
# Exportar archivos para LightGBM CLI (5-fold del 80%) + HOLDOUT (20%)
# =============================================================================
def export_lgbm_file(X_df: pd.DataFrame, y_df: pd.Series, filename: str) -> None:
    """Concatena y,label (col 0) + X (col 1..n) y exporta a TSV sin encabezado."""
    df_out = pd.concat([y_df.reset_index(drop=True), X_df.reset_index(drop=True)], axis=1)
    df_out.to_csv(filename, sep="\t", index=False, header=False)


# ----- 5 folds del 80% (X_train_opt, y_train_opt) -----
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
for fold_idx, (train_idx, valid_idx) in enumerate(kfold.split(X_train_opt, y_train_opt)):
    X_train_base = X_train_opt.iloc[train_idx].copy()
    X_valid_base = X_train_opt.iloc[valid_idx].copy()
    y_train = y_train_opt.iloc[train_idx]
    y_valid = y_train_opt.iloc[valid_idx]

    train_pos = df.index.get_indexer(X_train_opt.index[train_idx])
    valid_pos = df.index.get_indexer(X_train_opt.index[valid_idx])

    X_train_base, X_valid_base = inject_rescuer_count_fold(
        X_train_base, X_valid_base, tr_idx=train_pos, va_idx=valid_pos, df_full=df
    )

    if USER_RF_LEAF_FEATURES:
        X_train_ext, X_valid_ext, _ = build_rf_leaf_features_train_valid(
            X_train_base,
            X_valid_base,
            y_train,
            num_trees=20,
            num_leaves=16,
            min_data_in_leaf=100,
            mtry_ratio=0.2,
            seed=42,
        )
    else:
        X_train_ext, X_valid_ext = X_train_base, X_valid_base

    # Índices de categóricas para el CLI (recordar: label está en la columna 0)
    cat_cols_fold = [c for c in CATEGORICALS if c in X_train_ext.columns]
    cat_idx_fold = [X_train_ext.columns.get_loc(c) + 1 for c in cat_cols_fold]
    cat_idx_str_fold = ",".join(map(str, cat_idx_fold)) if cat_idx_fold else ""

    train_file = f"folds/train_fold_{fold_idx}.txt"
    valid_file = f"folds/valid_fold_{fold_idx}.txt"
    valid_labels = f"folds/y_valid_fold_{fold_idx}.txt"
    model_file_txt = f"folds/model_fold_{fold_idx}.txt"
    pred_file = f"folds/predictions_fold_{fold_idx}.txt"
    config_train_file = f"folds/config_train_fold_{fold_idx}.txt"
    config_pred_file = f"folds/config_pred_fold_{fold_idx}.txt"

    export_lgbm_file(X_train_ext, y_train, train_file)
    export_lgbm_file(X_valid_ext, y_valid, valid_file)
    y_valid.reset_index(drop=True).to_csv(valid_labels, index=False, header=False)

    config_train_text = f"""task=train
objective=multiclass
num_class={NUM_CLASS}
metric=multi_logloss,multi_error
data={train_file}
valid_data={valid_file}
label_column=0
output_model={model_file_txt}
num_iterations=1000
early_stopping_round=50
learning_rate={best_params['learning_rate']}
num_leaves={best_params['num_leaves']}
min_data_in_leaf={best_params['min_data_in_leaf']}
feature_fraction={best_params['feature_fraction']}
bagging_fraction={best_params['bagging_fraction']}
bagging_freq={best_params['bagging_freq']}
lambda_l1={best_params['lambda_l1']}
lambda_l2={best_params['lambda_l2']}
seed=42
feature_fraction_seed=42
bagging_seed=42
drop_seed=42
verbosity=1
"""
    if cat_idx_str_fold:
        config_train_text += f"categorical_feature={cat_idx_str_fold}\n"
    Path(config_train_file).write_text(config_train_text, encoding="utf-8")

    config_pred_text = f"""task=predict
input_model={model_file_txt}
data={valid_file}
output_result={pred_file}
"""
    Path(config_pred_file).write_text(config_pred_text, encoding="utf-8")

# ----- HOLDOUT limpio (20%) -----
hold_tr_base = X_train_opt.copy()
hold_va_base = X_valid_opt.copy()

tr_pos = df.index.get_indexer(hold_tr_base.index)
va_pos = df.index.get_indexer(hold_va_base.index)
hold_tr_base, hold_va_base = inject_rescuer_count_fold(
    hold_tr_base, hold_va_base, tr_idx=tr_pos, va_idx=va_pos, df_full=df
)

if USER_RF_LEAF_FEATURES:
    hold_tr_ext, hold_va_ext, _ = build_rf_leaf_features_train_valid(
        hold_tr_base,
        hold_va_base,
        y_train_opt,
        num_trees=20,
        num_leaves=16,
        min_data_in_leaf=100,
        mtry_ratio=0.2,
        seed=42,
    )
else:
    hold_tr_ext, hold_va_ext = hold_tr_base, hold_va_base

export_lgbm_file(hold_tr_ext, y_train_opt, "folds/holdout_train.txt")
export_lgbm_file(hold_va_ext, y_valid_opt, "folds/holdout_valid.txt")
y_valid_opt.reset_index(drop=True).to_csv(
    "folds/y_holdout_valid.txt", index=False, header=False
)

cat_cols_hold = [c for c in CATEGORICALS if c in hold_tr_ext.columns]
cat_idx_hold = [hold_tr_ext.columns.get_loc(c) + 1 for c in cat_cols_hold]
cat_idx_str_hold = ",".join(map(str, cat_idx_hold)) if cat_idx_hold else ""

config_train_hold = f"""task=train
objective=multiclass
num_class={NUM_CLASS}
metric=multi_logloss,multi_error
data=folds/holdout_train.txt
valid_data=folds/holdout_valid.txt
label_column=0
output_model=folds/model_holdout.txt
num_iterations=1000
early_stopping_round=50
learning_rate={best_params['learning_rate']}
num_leaves={best_params['num_leaves']}
min_data_in_leaf={best_params['min_data_in_leaf']}
feature_fraction={best_params['feature_fraction']}
bagging_fraction={best_params['bagging_fraction']}
bagging_freq={best_params['bagging_freq']}
lambda_l1={best_params['lambda_l1']}
lambda_l2={best_params['lambda_l2']}
seed=42
feature_fraction_seed=42
bagging_seed=42
drop_seed=42
verbosity=1
"""
if cat_idx_str_hold:
    config_train_hold += f"categorical_feature={cat_idx_str_hold}\n"
Path("folds/config_train_holdout.txt").write_text(config_train_hold, encoding="utf-8")

config_pred_hold = """task=predict
input_model=folds/model_holdout.txt
data=folds/holdout_valid.txt
output_result=folds/predictions_holdout.txt
"""
Path("folds/config_pred_holdout.txt").write_text(config_pred_hold, encoding="utf-8")

# ----- Entrenamiento final con TODO el train -----
if USER_RF_LEAF_FEATURES:
    # Entrenar encoder RF sobre todo el train y guardar vocabulario de hojas
    rf_tr_all, rf_cols_all = fit_save_rf_leaf_encoder(
        X, y, num_trees=20, num_leaves=16, min_data_in_leaf=100, mtry_ratio=0.2, seed=42
    )
    X_all_ext = pd.concat([X, rf_tr_all], axis=1)
else:
    X_all_ext = X

all_train_file = "folds/train_all.txt"
export_lgbm_file(X_all_ext, y, all_train_file)

cat_cols_all = [c for c in CATEGORICALS if c in X_all_ext.columns]
cat_idx_all = [X_all_ext.columns.get_loc(c) + 1 for c in cat_cols_all]
cat_idx_str_all = ",".join(str(i) for i in cat_idx_all) if cat_idx_all else ""

all_config_file = "folds/config_train_all.txt"
FINAL_NUM_ITER = 20  # iteraciones para el modelo final (sirve para inferencia rápida)
config_all_text = f"""task=train
objective=multiclass
num_class={NUM_CLASS}
metric=none
data={all_train_file}
label_column=0
output_model=folds/model_all.txt
num_iterations={FINAL_NUM_ITER}
learning_rate={best_params['learning_rate']}
num_leaves={best_params['num_leaves']}
min_data_in_leaf={best_params['min_data_in_leaf']}
feature_fraction={best_params['feature_fraction']}
bagging_fraction={best_params['bagging_fraction']}
bagging_freq={best_params['bagging_freq']}
lambda_l1={best_params['lambda_l1']}
lambda_l2={best_params['lambda_l2']}
seed=42
feature_fraction_seed=42
bagging_seed=42
drop_seed=42
verbosity=1
save_binary=false
"""
if cat_idx_str_all:
    config_all_text += f"categorical_feature={cat_idx_str_all}\n"
Path(all_config_file).write_text(config_all_text, encoding="utf-8")

print(f"config_train_all.txt generado con metric=none y num_iterations={FINAL_NUM_ITER}")


# =============================================================================
# Inferencia sobre test.csv (Kaggle)
# =============================================================================
def encode_with_saved_map(df_in: pd.DataFrame, enc_path: Path = ENC_PATH) -> pd.DataFrame:
    """Aplica los mapeos de Care y ColorPattern persistidos; asigna un valor por defecto si aparece una categoría nueva."""
    enc_map = json.loads(Path(enc_path).read_text(encoding="utf-8"))
    for col in ["Care", "ColorPattern"]:
        mapping = enc_map[col]
        default_idx = mapping.get("otro", next(iter(mapping.values()), 0))
        df_in[col] = df_in[col].astype(str).map(mapping).fillna(default_idx).astype(int)
    return df_in


TEST_PATH = Path("test.csv")
infer_file = "folds/infer.txt"
config_pred_infer = "folds/config_pred_infer.txt"

if TEST_PATH.exists():
    print("test.csv encontrado — preparando inferencia...")
    test_df = pd.read_csv(TEST_PATH)

    # Mismo feature engineering que en train
    test_df["Care"] = test_df.apply(classify_care, axis=1)
    test_df["ColorPattern"] = test_df.apply(classify_color, axis=1)
    test_df["HasName"] = (test_df["Name"].fillna("").str.strip() != "").astype(int)
    test_df["DescLength"] = test_df["Description"].fillna("").apply(lambda x: len(x.split()))
    test_df["PhotoDescCombo"] = test_df["PhotoAmt"] * test_df["DescLength"]
    test_df["FeeZero"] = (test_df["Fee"] == 0).astype(int)
    test_df["IsBaby"] = (test_df["Age"] < 6).astype(int)
    test_df["RescuerListingCount"] = test_df["RescuerID"].map(rescuer_counts).fillna(1)

    # Codificar categóricas con el mapping guardado
    test_df = encode_with_saved_map(test_df)

    # Features base en el mismo orden
    X_test = test_df[features]

    # Si la bandera está activa, aplicar el encoder RF guardado y alinear columnas
    if USER_RF_LEAF_FEATURES:
        rf_te = transform_with_saved_rf_encoder(X_test)
        X_test_ext = pd.concat([X_test, rf_te], axis=1)
    else:
        X_test_ext = X_test

    print(f"[CHECK] cols train_all={X_all_ext.shape[1]} | cols test={X_test_ext.shape[1]}")

    # Columna 0 = label dummy (0) para respetar el formato del CLI
    export_lgbm_file(X_test_ext, pd.Series(0, index=X_test_ext.index), infer_file)

    # Config de predicción para el modelo final
    Path(config_pred_infer).write_text(
        f"""task=predict
input_model=folds/model_all.txt
data={infer_file}
output_result=folds/pred_infer.txt
""",
        encoding="utf-8",
    )

    print("Inferencia preparada: folds/infer.txt y folds/config_pred_infer.txt.")
else:
    print("test.csv no encontrado — se omite la inferencia final automática.")


# =============================================================================
# Lanzar Optuna Dashboard (opcional)
# =============================================================================
def launch_dashboard() -> None:
    """Lanza optuna-dashboard en 127.0.0.1:8080 (Windows abre una consola aparte)."""
    dashboard_cmd = f'optuna-dashboard "{STORAGE_URL}" --host 127.0.0.1 --port 8080'
    print("\nLanzando Optuna Dashboard...")
    print(f"   {dashboard_cmd}")
    try:
        if os.name == "nt":  # Windows
            os.system(f'start "" cmd /k {dashboard_cmd}')
        else:
            subprocess.Popen(
                dashboard_cmd.split(),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception as e:
        print(f"No se pudo lanzar optuna-dashboard automáticamente: {e}")
        print(f"Ejecutar manualmente: {dashboard_cmd}")


launch_dashboard()
